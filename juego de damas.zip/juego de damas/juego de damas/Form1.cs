﻿namespace juego_de_damas
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            InicializarTablero();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void InicializarTablero()
        {
            tableroPanel.RowCount = 8;
            tableroPanel.ColumnCount = 8;
            tableroPanel.Controls.Clear();

            for (int fila = 0; fila < 8; fila++)
            {
                for (int col = 0; col < 8; col++)
                {
                    Button celda = new Button();
                    celda.Dock = DockStyle.Fill;
                    celda.Tag = new Point(fila, col);
                    celda.Click += Celda_Click;


                    if ((fila + col) % 2 == 0)
                        celda.BackColor = Color.White;
                    else
                        celda.BackColor = Color.Black;

                    tableroPanel.Controls.Add(celda, col, fila);
                    tablero[fila, col] = celda;


                    if (fila < 3 && (fila + col) % 2 != 0)
                        matrizTablero[fila, col] = 1;
                    else if (fila > 4 && (fila + col) % 2 != 0)
                        matrizTablero[fila, col] = 2;
                    else
                        matrizTablero[fila, col] = 0;
                }
            }

            ActualizarTablero();
        }
        private void ActualizarTablero()
        {
            for (int fila = 0; fila < 8; fila++)
            {
                for (int col = 0; col < 8; col++)
                {
                    if (matrizTablero[fila, col] == 1)
                    {
                        tablero[fila, col].Text = "👑"; // Jugador 1
                        tablero[fila, col].ForeColor = Color.Red; // Color rojo para jugador 1
                    }
                    else if (matrizTablero[fila, col] == 2)
                    {
                        tablero[fila, col].Text = "👑"; // Jugador 2
                        tablero[fila, col].ForeColor = Color.Blue; // Color azul para jugador 2
                    }
                    else if (matrizTablero[fila, col] == 3)
                    {
                        tablero[fila, col].Text = "👑"; // Dama de jugador 1
                        tablero[fila, col].ForeColor = Color.DarkRed; // Color rojo oscuro para dama de jugador 1
                    }
                    else if (matrizTablero[fila, col] == 4)
                    {
                        tablero[fila, col].Text = "👑"; // Dama de jugador 2
                        tablero[fila, col].ForeColor = Color.DarkBlue; // Color azul oscuro para dama de jugador 2
                    }
                    else
                    {
                        tablero[fila, col].Text = ""; // Casilla vacía
                        tablero[fila, col].ForeColor = Color.Black; // Restablecer color si está vacío
                    }
                }
            }
        }


        private void Celda_Click(object sender, EventArgs e)
        {
            if (!juegoIniciado)
            {
                MessageBox.Show("Por favor, inicia el juego primero.", "Juego no iniciado");
                return;
            }

            Button botonClicado = sender as Button;
            Point pos = (Point)botonClicado.Tag;
            int fila = pos.X;
            int col = pos.Y;

            if (piezaSeleccionada == null)
            {
                if ((turnoJugador == 1 && (matrizTablero[fila, col] == 1 || matrizTablero[fila, col] == 3)) ||
                    (turnoJugador == 2 && (matrizTablero[fila, col] == 2 || matrizTablero[fila, col] == 4)))
                {
                    piezaSeleccionada = pos;

                }
            }
            else
            {
                Point origen = piezaSeleccionada.Value;
                int pieza = matrizTablero[origen.X, origen.Y];
                if (MovimientoValido(origen, pos))
                {
                    matrizTablero[pos.X, pos.Y] = pieza;
                    matrizTablero[origen.X, origen.Y] = 0;

                    if (turnoJugador == 1 && pos.X == 7) matrizTablero[pos.X, pos.Y] = 3;
                    else if (turnoJugador == 2 && pos.X == 0) matrizTablero[pos.X, pos.Y] = 4;

                    turnoJugador = (turnoJugador == 1) ? 2 : 1;
                    piezaSeleccionada = null;
                    ActualizarTablero();

                    VerificarGanador();
                }
                else
                {
                    tablero[origen.X, origen.Y].BackColor = (origen.X + origen.Y) % 2 == 0 ? Color.White : Color.Black;
                    piezaSeleccionada = null;
                }
            }
        }


        private bool MovimientoValido(Point origen, Point destino)
        {
            int pieza = matrizTablero[origen.X, origen.Y];
            int dx = destino.X - origen.X;
            int dy = destino.Y - origen.Y;


            if (matrizTablero[destino.X, destino.Y] != 0) return false;


            if (Math.Abs(dx) == 1 && Math.Abs(dy) == 1)
            {
                if ((pieza == 1 && dx == 1) || (pieza == 2 && dx == -1) || pieza > 2)
                    return true;
            }
            else if (Math.Abs(dx) == 2 && Math.Abs(dy) == 2)
            {

                int medioX = origen.X + dx / 2;
                int medioY = origen.Y + dy / 2;
                int piezaCapturada = matrizTablero[medioX, medioY];

                if ((turnoJugador == 1 && (piezaCapturada == 2 || piezaCapturada == 4)) ||
                    (turnoJugador == 2 && (piezaCapturada == 1 || piezaCapturada == 3)))
                {
                    matrizTablero[medioX, medioY] = 0;
                    return true;
                }
            }

            return false;
        }

        private void VerificarGanador()
        {
            bool jugador1TienePiezas = false;
            bool jugador2TienePiezas = false;

            for (int fila = 0; fila < 8; fila++)
            {
                for (int col = 0; col < 8; col++)
                {
                    if (matrizTablero[fila, col] == 1 || matrizTablero[fila, col] == 3) jugador1TienePiezas = true;
                    if (matrizTablero[fila, col] == 2 || matrizTablero[fila, col] == 4) jugador2TienePiezas = true;
                }
            }

            if (!jugador1TienePiezas)
            {
                juegoIniciado = false;
                MessageBox.Show($"{nombreJugador2} ha ganado el juego! 🎉\n\n" +
                                $"Fecha de la victoria: {DateTime.Now.ToLongDateString()}\n" +
                                $"Hora: {DateTime.Now.ToLongTimeString()}\n\n" +
                                "¡Felicidades! Has capturado todas las piezas de tu oponente. 🏆\n" +
                                "¡Gracias por jugar! ¿Quieres jugar otra partida?",
                                "Juego terminado", MessageBoxButtons.YesNo);
            }
            else if (!jugador2TienePiezas)
            {
                juegoIniciado = false;
                MessageBox.Show($"{nombreJugador1} ha ganado el juego! 🎉\n\n" +
                                $"Fecha de la victoria: {DateTime.Now.ToLongDateString()}\n" +
                                $"Hora: {DateTime.Now.ToLongTimeString()}\n\n" +
                                "¡Felicidades! Has capturado todas las piezas de tu oponente. 🏆\n" +
                                "¡Gracias por jugar! ¿Quieres jugar otra partida?",
                                "Juego terminado", MessageBoxButtons.YesNo);
            }
        }

        private void BTNINICIARJUEGO_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtjugador1.Text) || string.IsNullOrEmpty(txtjugador2.Text))
            {
                MessageBox.Show("Por favor, asegúrate de que ambos jugadores tengan un nombre antes de empezar.");
                return;
            }

            string mensajeInicio = $"?? ¡El juego ha comenzado! ??\n\n" +
                                    $"Jugador 1 (Rojas): {txtjugador1.Text}\n" +
                                    $"Jugador 2 (Azules): {txtjugador2.Text}\n\n" +
                                    $"Fecha: {DateTime.Now.ToLongDateString()}\n" +
                                    $"Hora: {DateTime.Now.ToLongTimeString()}\n\n" +
                                    "Reglas del juego:\n" +
                                    "- Las fichas rojas comienzan primero.\n" +
                                    "- Solo puedes moverte en las casillas negras.\n" +
                                    "- ¡Captura todas las fichas del oponente para ganar!\n\n" +
                                    "¡Que gane el mejor! ??";

            MessageBox.Show(mensajeInicio, "Juego Iniciado");
            juegoIniciado = true;
        }

        private void lblartur_Click(object sender, EventArgs e)
        {

        }

        private void lblwaldo_Click(object sender, EventArgs e)
        {

        }

        private void jbtnjugador2_Click(object sender, EventArgs e)
        {
            nombreJugador2 = txtjugador2.Text;
            if (string.IsNullOrEmpty(nombreJugador2))
            {
                MessageBox.Show("Es necesario ingresar el nombre del Jugador 2.");
            }
            else
            {
                MessageBox.Show($"¡Jugador 2 registrado! Nombre: {nombreJugador2}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtjugador1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnjuagdor1_Click(object sender, EventArgs e)
        {
            nombreJugador1 = txtjugador1.Text;
            if (string.IsNullOrEmpty(nombreJugador1))
            {
                MessageBox.Show("Es necesario ingresar el nombre del Jugador 1.");
            }
            else
            {
                MessageBox.Show($"¡Jugador 1 registrado! Nombre: {nombreJugador1}");
            }
        }
        private Button[,] tablero = new Button[8, 8];
        private int[,] matrizTablero = new int[8, 8];
        private Point? piezaSeleccionada = null;
        private int turnoJugador = 1;
        private bool juegoIniciado = false;
        private string nombreJugador1 = "";
        private string nombreJugador2 = "";
    }
}
