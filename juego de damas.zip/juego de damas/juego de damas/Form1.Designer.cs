﻿namespace juego_de_damas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableroPanel = new TableLayoutPanel();
            BTNINICIARJUEGO = new Button();
            btnjuagdor1 = new Button();
            btnjugador2 = new Button();
            txtjugador1 = new TextBox();
            txtjugador2 = new TextBox();
            SuspendLayout();
            // 
            // tableroPanel
            // 
            tableroPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.InsetDouble;
            tableroPanel.ColumnCount = 8;
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5F));
            tableroPanel.Location = new Point(118, 82);
            tableroPanel.Name = "tableroPanel";
            tableroPanel.RowCount = 8;
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5F));
            tableroPanel.Size = new Size(488, 377);
            tableroPanel.TabIndex = 0;
            tableroPanel.Paint += tableLayoutPanel1_Paint;
            // 
            // BTNINICIARJUEGO
            // 
            BTNINICIARJUEGO.Location = new Point(531, 52);
            BTNINICIARJUEGO.Name = "BTNINICIARJUEGO";
            BTNINICIARJUEGO.Size = new Size(75, 23);
            BTNINICIARJUEGO.TabIndex = 1;
            BTNINICIARJUEGO.Text = "GO";
            BTNINICIARJUEGO.UseVisualStyleBackColor = true;
            BTNINICIARJUEGO.Click += BTNINICIARJUEGO_Click;
            // 
            // btnjuagdor1
            // 
            btnjuagdor1.Location = new Point(243, 24);
            btnjuagdor1.Name = "btnjuagdor1";
            btnjuagdor1.Size = new Size(75, 23);
            btnjuagdor1.TabIndex = 7;
            btnjuagdor1.Text = "guardar";
            btnjuagdor1.UseVisualStyleBackColor = true;
            btnjuagdor1.Click += btnjuagdor1_Click;
            // 
            // btnjugador2
            // 
            btnjugador2.Location = new Point(243, 53);
            btnjugador2.Name = "btnjugador2";
            btnjugador2.Size = new Size(75, 23);
            btnjugador2.TabIndex = 8;
            btnjugador2.Text = "guardar";
            btnjugador2.UseVisualStyleBackColor = true;
            btnjugador2.Click += jbtnjugador2_Click;
            // 
            // txtjugador1
            // 
            txtjugador1.Location = new Point(137, 24);
            txtjugador1.Name = "txtjugador1";
            txtjugador1.Size = new Size(100, 23);
            txtjugador1.TabIndex = 9;
            txtjugador1.Text = "Jugador1";
            txtjugador1.TextChanged += txtjugador1_TextChanged;
            // 
            // txtjugador2
            // 
            txtjugador2.Location = new Point(137, 53);
            txtjugador2.Name = "txtjugador2";
            txtjugador2.Size = new Size(100, 23);
            txtjugador2.TabIndex = 10;
            txtjugador2.Text = "Jugador2";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonShadow;
            ClientSize = new Size(700, 523);
            Controls.Add(txtjugador2);
            Controls.Add(txtjugador1);
            Controls.Add(btnjugador2);
            Controls.Add(btnjuagdor1);
            Controls.Add(BTNINICIARJUEGO);
            Controls.Add(tableroPanel);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "Form1";
            Opacity = 0.7D;
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableroPanel;
        private Button BTNINICIARJUEGO;
        private Button btnjuagdor1;
        private Button btnjugador2;
        private TextBox txtjugador1;
        private TextBox txtjugador2;
    }
}
