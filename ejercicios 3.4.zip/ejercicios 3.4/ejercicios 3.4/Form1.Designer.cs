﻿namespace ejercicios_3._4_
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            textBox1 = new TextBox();
            btnserie1 = new Button();
            btnserie2 = new Button();
            btnserie3 = new Button();
            btnserie4 = new Button();
            btnserie5 = new Button();
            btnserie6 = new Button();
            btnserie7 = new Button();
            btnserie8 = new Button();
            btnserie9 = new Button();
            btnserie10 = new Button();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            btnfuncion1 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            textBoxCantidad = new TextBox();
            textBoxIVA = new TextBox();
            textBoxAltura = new TextBox();
            textBoxRadio = new TextBox();
            textBoxNumero2 = new TextBox();
            textBoxNumero1 = new TextBox();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(630, 12);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(142, 379);
            listBox1.TabIndex = 0;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(12, 23);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(101, 23);
            textBox1.TabIndex = 1;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // btnserie1
            // 
            btnserie1.Location = new Point(12, 98);
            btnserie1.Name = "btnserie1";
            btnserie1.Size = new Size(75, 23);
            btnserie1.TabIndex = 2;
            btnserie1.Text = "serie1";
            btnserie1.UseVisualStyleBackColor = true;
            btnserie1.Click += button1_Click;
            // 
            // btnserie2
            // 
            btnserie2.Location = new Point(93, 98);
            btnserie2.Name = "btnserie2";
            btnserie2.Size = new Size(75, 23);
            btnserie2.TabIndex = 3;
            btnserie2.Text = "serie2";
            btnserie2.UseVisualStyleBackColor = true;
            btnserie2.Click += btnserie2_Click;
            // 
            // btnserie3
            // 
            btnserie3.Location = new Point(174, 98);
            btnserie3.Name = "btnserie3";
            btnserie3.Size = new Size(75, 23);
            btnserie3.TabIndex = 4;
            btnserie3.Text = "serie3";
            btnserie3.UseVisualStyleBackColor = true;
            btnserie3.Click += btnserie3_Click;
            // 
            // btnserie4
            // 
            btnserie4.Location = new Point(255, 98);
            btnserie4.Name = "btnserie4";
            btnserie4.Size = new Size(75, 23);
            btnserie4.TabIndex = 5;
            btnserie4.Text = "serie4";
            btnserie4.UseVisualStyleBackColor = true;
            btnserie4.Click += btnserie4_Click;
            // 
            // btnserie5
            // 
            btnserie5.Location = new Point(336, 98);
            btnserie5.Name = "btnserie5";
            btnserie5.Size = new Size(75, 23);
            btnserie5.TabIndex = 6;
            btnserie5.Text = "serie5";
            btnserie5.UseVisualStyleBackColor = true;
            btnserie5.Click += btnserie5_Click;
            // 
            // btnserie6
            // 
            btnserie6.Location = new Point(417, 98);
            btnserie6.Name = "btnserie6";
            btnserie6.Size = new Size(75, 23);
            btnserie6.TabIndex = 7;
            btnserie6.Text = "serie6";
            btnserie6.UseVisualStyleBackColor = true;
            btnserie6.Click += btnserie6_Click;
            // 
            // btnserie7
            // 
            btnserie7.Location = new Point(498, 98);
            btnserie7.Name = "btnserie7";
            btnserie7.Size = new Size(75, 23);
            btnserie7.TabIndex = 8;
            btnserie7.Text = "serie7";
            btnserie7.UseVisualStyleBackColor = true;
            btnserie7.Click += btnserie7_Click;
            // 
            // btnserie8
            // 
            btnserie8.Location = new Point(12, 127);
            btnserie8.Name = "btnserie8";
            btnserie8.Size = new Size(75, 23);
            btnserie8.TabIndex = 9;
            btnserie8.Text = "serie8";
            btnserie8.UseVisualStyleBackColor = true;
            btnserie8.Click += btnserie8_Click;
            // 
            // btnserie9
            // 
            btnserie9.Location = new Point(93, 127);
            btnserie9.Name = "btnserie9";
            btnserie9.Size = new Size(75, 23);
            btnserie9.TabIndex = 10;
            btnserie9.Text = "serie9";
            btnserie9.UseVisualStyleBackColor = true;
            btnserie9.Click += btnserie9_Click;
            // 
            // btnserie10
            // 
            btnserie10.Location = new Point(174, 127);
            btnserie10.Name = "btnserie10";
            btnserie10.Size = new Size(75, 23);
            btnserie10.TabIndex = 11;
            btnserie10.Text = "serie10";
            btnserie10.UseVisualStyleBackColor = true;
            btnserie10.Click += btnserie10_Click;
            // 
            // button1
            // 
            button1.Location = new Point(255, 127);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 12;
            button1.Text = "serie11";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // button2
            // 
            button2.Location = new Point(336, 127);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 13;
            button2.Text = "serie12";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(417, 127);
            button3.Name = "button3";
            button3.Size = new Size(75, 23);
            button3.TabIndex = 14;
            button3.Text = "serie13";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(498, 127);
            button4.Name = "button4";
            button4.Size = new Size(75, 23);
            button4.TabIndex = 15;
            button4.Text = "serie14";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(12, 156);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 16;
            button5.Text = "serie15";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // btnfuncion1
            // 
            btnfuncion1.Location = new Point(12, 222);
            btnfuncion1.Name = "btnfuncion1";
            btnfuncion1.Size = new Size(75, 23);
            btnfuncion1.TabIndex = 17;
            btnfuncion1.Text = "funcion1";
            btnfuncion1.UseVisualStyleBackColor = true;
            btnfuncion1.Click += btnfuncion1_Click;
            // 
            // button6
            // 
            button6.Location = new Point(93, 222);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 18;
            button6.Text = "funcion2";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click_1;
            // 
            // button7
            // 
            button7.Location = new Point(174, 222);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 19;
            button7.Text = "funcion3";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(12, 293);
            button8.Name = "button8";
            button8.Size = new Size(75, 23);
            button8.TabIndex = 20;
            button8.Text = "funcion4";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(255, 293);
            button9.Name = "button9";
            button9.Size = new Size(75, 23);
            button9.TabIndex = 21;
            button9.Text = "funcion5";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(255, 222);
            button10.Name = "button10";
            button10.Size = new Size(75, 23);
            button10.TabIndex = 22;
            button10.Text = "funcion6";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(336, 222);
            button11.Name = "button11";
            button11.Size = new Size(75, 23);
            button11.TabIndex = 23;
            button11.Text = "funcion7";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(417, 222);
            button12.Name = "button12";
            button12.Size = new Size(75, 23);
            button12.TabIndex = 24;
            button12.Text = "funcion8";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button13
            // 
            button13.Location = new Point(12, 362);
            button13.Name = "button13";
            button13.Size = new Size(75, 23);
            button13.TabIndex = 25;
            button13.Text = "funcion9";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Location = new Point(498, 222);
            button14.Name = "button14";
            button14.Size = new Size(75, 23);
            button14.TabIndex = 26;
            button14.Text = "funcion10";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // textBoxCantidad
            // 
            textBoxCantidad.Location = new Point(12, 264);
            textBoxCantidad.Name = "textBoxCantidad";
            textBoxCantidad.Size = new Size(101, 23);
            textBoxCantidad.TabIndex = 27;
            textBoxCantidad.Text = "Cantidad";
            // 
            // textBoxIVA
            // 
            textBoxIVA.Location = new Point(119, 264);
            textBoxIVA.Name = "textBoxIVA";
            textBoxIVA.Size = new Size(101, 23);
            textBoxIVA.TabIndex = 28;
            textBoxIVA.Text = "IVA";
            // 
            // textBoxAltura
            // 
            textBoxAltura.Location = new Point(362, 264);
            textBoxAltura.Name = "textBoxAltura";
            textBoxAltura.Size = new Size(101, 23);
            textBoxAltura.TabIndex = 30;
            textBoxAltura.Text = "altura";
            textBoxAltura.TextChanged += textBoxAltura_TextChanged;
            // 
            // textBoxRadio
            // 
            textBoxRadio.Location = new Point(255, 264);
            textBoxRadio.Name = "textBoxRadio";
            textBoxRadio.Size = new Size(101, 23);
            textBoxRadio.TabIndex = 29;
            textBoxRadio.Text = "Radio";
            textBoxRadio.TextChanged += textBox3_TextChanged;
            // 
            // textBoxNumero2
            // 
            textBoxNumero2.Location = new Point(119, 333);
            textBoxNumero2.Name = "textBoxNumero2";
            textBoxNumero2.Size = new Size(101, 23);
            textBoxNumero2.TabIndex = 32;
            textBoxNumero2.Text = "numero2";
            // 
            // textBoxNumero1
            // 
            textBoxNumero1.Location = new Point(12, 333);
            textBoxNumero1.Name = "textBoxNumero1";
            textBoxNumero1.Size = new Size(101, 23);
            textBoxNumero1.TabIndex = 31;
            textBoxNumero1.Text = "numero1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBoxNumero2);
            Controls.Add(textBoxNumero1);
            Controls.Add(textBoxAltura);
            Controls.Add(textBoxRadio);
            Controls.Add(textBoxIVA);
            Controls.Add(textBoxCantidad);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(btnfuncion1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(btnserie10);
            Controls.Add(btnserie9);
            Controls.Add(btnserie8);
            Controls.Add(btnserie7);
            Controls.Add(btnserie6);
            Controls.Add(btnserie5);
            Controls.Add(btnserie4);
            Controls.Add(btnserie3);
            Controls.Add(btnserie2);
            Controls.Add(btnserie1);
            Controls.Add(textBox1);
            Controls.Add(listBox1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private TextBox textBox1;
        private Button btnserie1;
        private Button btnserie2;
        private Button btnserie3;
        private Button btnserie4;
        private Button btnserie5;
        private Button btnserie6;
        private Button btnserie7;
        private Button btnserie8;
        private Button btnserie9;
        private Button btnserie10;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button btnfuncion1;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private TextBox textBoxCantidad;
        private TextBox textBoxIVA;
        private TextBox textBoxAltura;
        private TextBox textBoxRadio;
        private TextBox textBoxNumero2;
        private TextBox textBoxNumero1;
    }
}
