namespace ejercicios_3._4_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear(); 
            for (int i = 1; i <= 25; i += 3)
            {
                listBox1.Items.Add(i); 
            }
        }

        private void btnserie2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int i = 3; i <= 38; i += 5)
            {
                listBox1.Items.Add(i);
            }
        }

        private void btnserie5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int i = 1; i <= 9; i++)
            {
                listBox1.Items.Add(i * i);
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            listBox1.Items.Clear();
            for (int i = 1; i <= 5; i++)
            {
                listBox1.Items.Add($"{2 * i}/{6 - i}");
            }
        }

        private void btnserie3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int i = 2; i <= 256; i *= 2)
            {
                listBox1.Items.Add(i);
            }
        }

        private void btnserie4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int i = 3; i <= 2187; i *= 3)
            {
                listBox1.Items.Add(i);
            }
        }

        private void btnserie6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int i = 1; i <= 9; i++)
            {
                listBox1.Items.Add(i * i * i);
            }
        }

        private void btnserie7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int a = 0, b = 1;
            listBox1.Items.Add(a);
            listBox1.Items.Add(b);
            for (int i = 2; i < 10; i++)
            {
                int temp = a + b;
                listBox1.Items.Add(temp);
                a = b;
                b = temp;
            }
        }

        private void btnserie8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                listBox1.Items.Add(i * 3);
            }
        }

        private void btnserie9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int N = Convert.ToInt32(textBox1.Text);
            for (int i = 1; i <= N; i++)
            {
                listBox1.Items.Add(i * 5);
            }
        }

        private void btnserie10_Click(object sender, EventArgs e)
        {
            string[] numeros = textBox1.Text.Split(',');
            int sum = 0, count = numeros.Length;
            foreach (string numero in numeros)
            {
                sum += int.Parse(numero);
            }
            double promedio = (double)sum / count;
            listBox1.Items.Clear();
            listBox1.Items.Add($"Promedio: {promedio}");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int N = Convert.ToInt32(textBox1.Text);
            long factorial = 1;
            for (int i = 2; i <= N; i++)
            {
                factorial *= i;
            }
            listBox1.Items.Clear();
            listBox1.Items.Add($"Factorial: {factorial}");
        }

        private void button3_Click(object sender, EventArgs e)
        {

            listBox1.Items.Clear();
            int[] serie = { 1, 5, 3, 7, 5, 9, 7, 11, 9, 13, 11, 15, 13, 17, 15, 19, 17, 21, 19, 23 };
            foreach (var numero in serie)
            {
                listBox1.Items.Add(numero);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int N = Convert.ToInt32(textBox1.Text);
            for (int i = 5; i <= N; i += 5)
            {
                listBox1.Items.Add(i);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            int N = Convert.ToInt32(textBox1.Text);
            for (int i = N; i >= 1; i--)
            {
                listBox1.Items.Add(i);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }
        private double CalcularAreaCirculo(double radio)
        {
            return Math.PI * radio * radio;
        }
        private void button9_Click(object sender, EventArgs e)
        {
            double radio = Convert.ToDouble(textBoxRadio.Text);
            double altura = Convert.ToDouble(textBoxAltura.Text);
            double volumen = CalcularAreaCirculo(radio) * altura;
            MessageBox.Show($"El volumen del cilindro es: {volumen}");
        }

        private void btnfuncion1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("�Hola amiga!");

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            string nombre = textBox1.Text;
            MessageBox.Show($"Thola {nombre}1");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            int numero = Convert.ToInt32(textBox1.Text);
            long factorial = 1;
            for (int i = 2; i <= numero; i++)
            {
                factorial *= i;
            }
            MessageBox.Show($"El factorial de {numero} es: {factorial}");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            double cantidad = Convert.ToDouble(textBoxCantidad.Text);
            double iva = textBoxIVA.Text == "" ? 21 : Convert.ToDouble(textBoxIVA.Text);
            double total = cantidad + (cantidad * iva / 100);
            MessageBox.Show($"El total de la factura con IVA es: {total}");
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            string[] numeros = textBox1.Text.Split(',');
            double suma = 0;
            foreach (string numero in numeros)
            {
                suma += Convert.ToDouble(numero);
            }
            double media = suma / numeros.Length;
            MessageBox.Show($"La media es: {media}");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string[] numeros = textBox1.Text.Split(',');
            listBox1.Items.Clear();
            foreach (string numero in numeros)
            {
                double valor = Convert.ToDouble(numero);
                listBox1.Items.Add(valor * valor);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            string[] numeros = textBox1.Text.Split(',');
            double suma = 0, sumaCuadrados = 0;
            int n = numeros.Length;

            foreach (string numero in numeros)
            {
                double valor = Convert.ToDouble(numero);
                suma += valor;
                sumaCuadrados += valor * valor;
            }

            double media = suma / n;
            double varianza = (sumaCuadrados / n) - (media * media);
            double desviacionTipica = Math.Sqrt(varianza);

            MessageBox.Show($"Media: {media}, Varianza: {varianza}, Desviaci�n T�pica: {desviacionTipica}");
        }

        private void textBoxAltura_TextChanged(object sender, EventArgs e)
        {

        }
        private int CalcularMCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        private int CalcularMCM(int a, int b)
        {
            return (a * b) / CalcularMCD(a, b);
        }
        private void button13_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(textBoxNumero1.Text);
            int b = Convert.ToInt32(textBoxNumero2.Text);
            int mcd = CalcularMCD(a, b);
            int mcm = CalcularMCM(a, b);
            MessageBox.Show($"MCD: {mcd}, MCM: {mcm}");

        }
        private bool EsPrimo(int numero)
        {
            if (numero <= 1) return false;
            for (int i = 2; i <= Math.Sqrt(numero); i++)
            {
                if (numero % i == 0) return false;
            }
            return true;
        }
        private void button14_Click(object sender, EventArgs e)
        {
            int numero = Convert.ToInt32(textBox1.Text);
            if (EsPrimo(numero))
            {
                MessageBox.Show($"{numero} es primo.");
            }
            else
            {
                MessageBox.Show($"{numero} no es primo.");
            }
        }
    }
}
